
import json
import time
import requests
import os
from playwright.sync_api import sync_playwright
from datetime import datetime

# --- CONFIGURATION ---
API_ENDPOINT = "http://localhost:3000/api/email-logs" # Update to your production/local URL
# In production, pass cookies via ENV or dynamic file
COOKIES_DATA = os.getenv("GMAIL_COOKIES_JSON", "[]") 

def scrape_gmail():
    print(f"[{datetime.now().strftime('%H:%M:%S')}] Launching Secure Scraper...")
    
    with sync_playwright() as p:
        # Launch browser with specific args for stability
        browser = p.chromium.launch(
            headless=True,
            args=["--disable-blink-features=AutomationControlled"]
        )
        context = browser.new_context(
            user_agent="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
        )

        # 1. Load Cookies
        try:
            cookies = json.loads(COOKIES_DATA)
            if not cookies:
                # If ENV empty, try local file
                with open("gmail_cookies.json", "r") as f:
                    cookies = json.load(f)
            
            context.add_cookies(cookies)
            print(f"[+] Secure session established.")
        except Exception as e:
            print(f"[!] Critical Error: Could not load session context. {e}")
            return

        page = context.new_page()

        # 2. Navigate to Gmail (u/1 for multi-account support)
        target_url = "https://mail.google.com/mail/u/1/#search/from%3Anoreply%40roblox.com"
        print(f"[*] Accessing pipeline: {target_url}")
        
        try:
            page.goto(target_url, wait_until="networkidle", timeout=30000)
            
            # Wait for email rows
            page.wait_for_selector("tr.zA", timeout=15000)
            print("[+] Data matrix synchronized.")
            
            # 3. Extract Logs
            rows = page.query_selector_all("tr.zA")[:15]
            email_logs = []
            
            for row in rows:
                subject_el = row.query_selector("span.bog")
                snippet_el = row.query_selector("span.y2")
                time_el = row.query_selector("td.xW span")
                
                if subject_el:
                    log_entry = {
                        "id": f"gen-{int(time.time() * 1000)}",
                        "subject": subject_el.inner_text().strip(),
                        "snippet": snippet_el.inner_text().strip() if snippet_el else "",
                        "created_at": time_el.get_attribute("title") if time_el else datetime.now().isoformat(),
                        "account_id": "active_session", # Should be mapped dynamically
                        "status": "unread"
                    }
                    email_logs.append(log_entry)
            
            print(f"[*] Captured {len(email_logs)} logs. Syncing to Command Center...")

            # 4. Transmit to API
            try:
                response = requests.post(API_ENDPOINT, json={"logs": email_logs}, timeout=10)
                if response.status_code == 200:
                    print(f"[SUCCESS] {len(email_logs)} packets transmitted successfully.")
                else:
                    print(f"[FAILED] API rejected transmission. Status: {response.status_code}")
            except Exception as e:
                print(f"[ERROR] Could not reach API endpoint. {e}")

        except Exception as e:
            print(f"[!] Pipeline Interrupted: Selector timeout or session expired. {e}")
            # Potential refresh logic here

        browser.close()
        print(f"[{datetime.now().strftime('%H:%M:%S')}] Scraper task completed.")

if __name__ == "__main__":
    scrape_gmail()
