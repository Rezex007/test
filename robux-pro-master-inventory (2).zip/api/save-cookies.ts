
import { NextRequest, NextResponse } from 'next/server';
import { createClient } from '@supabase/supabase-js';

const supabase = createClient(process.env.SUPABASE_URL!, process.env.SUPABASE_SERVICE_ROLE_KEY!);

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { email, cookies } = body;

    if (!email || !cookies) {
      return NextResponse.json({ error: 'Email and Cookies are required' }, { status: 400 });
    }

    // อัปเดตข้อมูล Cookie สำหรับ Email นั้นๆ
    const { data, error } = await supabase
      .from('emails')
      .upsert({ 
        email, 
        cookies, 
        last_fetch: new Date().toISOString() 
      }, { onConflict: 'email' });

    if (error) throw error;

    return NextResponse.json({ success: true, message: 'Cookie saved successfully' });
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}
