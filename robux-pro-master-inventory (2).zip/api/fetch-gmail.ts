
// หมายเหตุ: ไฟล์นี้เป็นตัวอย่างโครงสร้าง API (Next.js App Router)
// คุณต้องนำไปรันใน Environment ที่มี Node.js และ Playwright ติดตั้งอยู่จริง

/*
import { NextRequest, NextResponse } from 'next/server';
import { chromium } from 'playwright';

export async function POST(req: NextRequest) {
  try {
    const { email, cookies } = await req.json();

    if (!cookies) {
      return NextResponse.json({ error: 'Cookies are required' }, { status: 400 });
    }

    const browser = await chromium.launch({ headless: true });
    const context = await browser.newContext();
    
    // ใส่คุกกี้ที่ได้รับจาก Frontend
    const parsedCookies = JSON.parse(cookies);
    await context.addCookies(parsedCookies);

    const page = await context.newPage();
    
    // วิ่งไปที่หน้าค้นหาเมลจาก Roblox
    await page.goto('https://mail.google.com/mail/u/0/#search/from%3Anoreply%40roblox.com');
    
    // รอจนกว่ารายการเมลจะโหลด
    await page.waitForSelector('tr.zA', { timeout: 15000 });
    
    const logs = await page.evaluate((emailAddr) => {
      const rows = Array.from(document.querySelectorAll('tr.zA')).slice(0, 10);
      return rows.map((row, index) => {
        const subject = row.querySelector('span.bog')?.textContent || 'No Subject';
        const snippet = row.querySelector('span.y2')?.textContent || '';
        const time = row.querySelector('td.xW span')?.title || new Date().toISOString();
        
        return {
          id: `real-${Date.now()}-${index}`,
          created_at: new Date(time).toISOString(),
          subject: subject,
          snippet: snippet,
          status: 'unread',
          account_id: emailAddr
        };
      });
    }, email);

    await browser.close();

    return NextResponse.json({ success: true, logs });
  } catch (error: any) {
    console.error('Playwright Error:', error);
    return NextResponse.json({ 
      error: 'Failed to fetch Gmail. Please check your cookies or connection.',
      details: error.message 
    }, { status: 500 });
  }
}
*/

// จำลองการทำงานสำหรับ Environment Frontend (สำหรับ Demo)
export const mockApiCall = async (email: string) => {
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve({
        success: true,
        logs: [
          {
            id: `real-${Date.now()}-1`,
            created_at: new Date().toISOString(),
            subject: 'Roblox Email Verification: novixo',
            snippet: 'Roblox Email Verification Hello, Thanks for choosing to secure your Roblox account...',
            status: 'unread',
            account_id: email
          },
          {
            id: `real-${Date.now()}-2`,
            created_at: new Date(Date.now() - 60000).toISOString(),
            subject: 'Your Roblox receipt [#1653-0936-3915]',
            snippet: 'Receipt from Roblox Amount paid ฿4000.00 Date paid Feb 14, 2026',
            status: 'unread',
            account_id: email
          }
        ]
      });
    }, 2000);
  });
};
