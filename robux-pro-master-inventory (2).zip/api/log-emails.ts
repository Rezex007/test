
// ไฟล์นี้จำลองโครงสร้าง app/api/log-emails/route.ts ใน Next.js App Router
import { NextRequest, NextResponse } from 'next/server';
import { createClient } from '@supabase/supabase-js';

const supabase = createClient(
  process.env.SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
);

export async function POST(req: NextRequest) {
  try {
    // 1. เช็ค API Key เพื่อความปลอดภัย
    const apiKey = req.headers.get('x-api-key');
    if (apiKey !== process.env.SCRAPER_API_KEY) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    // 2. รับข้อมูล JSON
    const body = await req.json();
    const { subject, snippet, date, account_id } = body;

    if (!subject || !account_id) {
      return NextResponse.json({ error: 'Missing required fields' }, { status: 400 });
    }

    // 3. บันทึกลง Supabase
    const { data, error } = await supabase
      .from('email_logs')
      .insert([
        { 
          subject, 
          snippet, 
          account_id, 
          created_at: date || new Date().toISOString(),
          status: 'pending' 
        }
      ]);

    if (error) throw error;

    return NextResponse.json({ success: true, data }, { status: 200 });
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}
