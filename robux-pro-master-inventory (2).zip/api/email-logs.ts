
import { NextRequest, NextResponse } from 'next/server';

// ในระบบจริง ข้อมูลนี้จะถูกบันทึกลง Supabase หรือ Database อื่นๆ
export async function POST(req: NextRequest) {
  try {
    const { logs } = await req.json();

    if (!logs || !Array.isArray(logs)) {
      return NextResponse.json({ error: 'Invalid logs format' }, { status: 400 });
    }

    console.log(`Received ${logs.length} logs from scraper.`);

    // ตัวอย่างการส่งข้อมูลไปยัง Frontend แบบ Real-time (ถ้าใช้ Socket.io หรือ Server-Sent Events)
    // หรือเพียงแค่บันทึกลง Database เพื่อให้ Frontend ดึงข้อมูลใหม่

    return NextResponse.json({ 
      success: true, 
      message: 'Logs received and processed',
      count: logs.length 
    });
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}
