
import React from 'react';
import { AppState } from '../types';
import { Wallet, Package, ArrowUpRight, ArrowDownRight, TrendingUp, AlertCircle, Inbox, Zap, Shield } from 'lucide-react';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer, 
  Cell,
  AreaChart,
  Area
} from 'recharts';

const Dashboard: React.FC<{ state: AppState }> = ({ state }) => {
  const totalCost = state.inventory.reduce((sum, item) => sum + item.cost, 0);
  const totalRevenue = state.inventory.filter(i => i.status === 'Sold').reduce((sum, item) => sum + item.price, 0);
  const totalProfit = state.inventory.filter(i => i.status === 'Sold').reduce((sum, item) => sum + (item.price - item.cost), 0);
  const unsoldItems = state.inventory.filter(i => i.status === 'Unsold').length;
  
  const chartData = [
    { name: 'Cost', value: totalCost, color: '#f43f5e' },
    { name: 'Revenue', value: totalRevenue, color: '#10b981' },
    { name: 'Profit', value: totalProfit, color: '#6366f1' },
  ];

  const recentLogs = state.logs.slice(0, 6);

  return (
    <div className="space-y-8 animate-in fade-in duration-700">
      <header className="flex justify-between items-end">
        <div>
          <div className="flex items-center gap-2 text-emerald-500 mb-2">
            <Zap size={16} fill="currentColor" />
            <span className="text-[10px] font-black uppercase tracking-[0.2em]">Operations Overview</span>
          </div>
          <h1 className="text-4xl font-extrabold tracking-tighter bg-gradient-to-r from-white to-zinc-500 bg-clip-text text-transparent">Command Center</h1>
        </div>
        <div className="glass px-4 py-2 rounded-2xl flex items-center gap-3 border-emerald-500/20 shadow-[0_0_15px_rgba(16,185,129,0.1)]">
          <div className="relative">
            <div className="w-2.5 h-2.5 bg-emerald-500 rounded-full animate-pulse"></div>
            <div className="absolute inset-0 w-2.5 h-2.5 bg-emerald-400 rounded-full blur-[4px] animate-ping"></div>
          </div>
          <span className="text-[11px] font-bold text-emerald-500 mono tracking-wider">SYSTEM_ACTIVE: v2.4.0</span>
        </div>
      </header>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-5">
        <StatCard 
          label="NET PROFIT" 
          value={`฿${totalProfit.toLocaleString()}`} 
          icon={<Wallet size={20} className="text-emerald-400" />} 
          trend="+ Live Data"
          color="emerald"
        />
        <StatCard 
          label="ACTIVE LOGS" 
          value={state.logs.length.toString()} 
          icon={<Inbox size={20} className="text-blue-400" />} 
          trend="Scraper Connected"
          color="blue"
        />
        <StatCard 
          label="STOCK VALUE" 
          value={`฿${totalCost.toLocaleString()}`} 
          icon={<Package size={20} className="text-indigo-400" />} 
          trend={`${state.inventory.length} Total Units`}
          color="indigo"
        />
        <StatCard 
          label="UNSOLD" 
          value={unsoldItems.toString()} 
          icon={<AlertCircle size={20} className="text-rose-400" />} 
          trend="Action Required"
          color="rose"
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Performance Chart */}
        <div className="lg:col-span-2 glass p-8 rounded-[2rem] glow-border flex flex-col h-[480px]">
          <div className="flex justify-between items-center mb-8">
            <div>
              <h3 className="text-xl font-bold tracking-tight">Financial Matrix</h3>
              <p className="text-xs text-zinc-500 font-medium">Real-time revenue and expenditure tracking</p>
            </div>
            <div className="flex gap-2">
               <div className="px-3 py-1 bg-zinc-900 border border-zinc-800 rounded-lg text-[10px] font-bold text-zinc-400 uppercase tracking-widest">Monthly Filter</div>
            </div>
          </div>
          
          <div className="flex-1 w-full min-h-0">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={chartData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <defs>
                  <linearGradient id="emeraldGradient" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="#10b981" stopOpacity={0.8}/>
                    <stop offset="100%" stopColor="#10b981" stopOpacity={0.1}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="4 4" stroke="#18181b" vertical={false} />
                <XAxis dataKey="name" stroke="#3f3f46" fontSize={10} fontWeight={700} tickLine={false} axisLine={false} tick={{dy: 10}} />
                <YAxis stroke="#3f3f46" fontSize={10} fontWeight={700} tickLine={false} axisLine={false} />
                <Tooltip 
                  cursor={{ fill: '#18181b', opacity: 0.5 }}
                  contentStyle={{ backgroundColor: '#09090b', border: '1px solid #27272a', borderRadius: '16px', fontSize: '11px', fontWeight: 'bold' }}
                />
                <Bar dataKey="value" radius={[12, 12, 4, 4]} barSize={65}>
                  {chartData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} fillOpacity={0.9} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Live Feed */}
        <div className="glass p-8 rounded-[2rem] glow-border flex flex-col h-[480px]">
          <div className="flex items-center justify-between mb-8">
            <h3 className="text-xl font-bold tracking-tight flex items-center gap-2">
               <Inbox size={22} className="text-emerald-500" /> Live Feed
            </h3>
            <span className="text-[9px] font-black bg-emerald-500/10 text-emerald-500 px-2 py-1 rounded-full animate-pulse-soft">STREAMING</span>
          </div>
          
          <div className="flex-1 overflow-y-auto space-y-4 pr-1 custom-scrollbar">
            {recentLogs.length > 0 ? (
              recentLogs.map((log, idx) => (
                <div key={log.id} className="p-4 bg-[#0c0c0e] border border-zinc-800/50 rounded-2xl hover:border-emerald-500/30 transition-all group relative overflow-hidden">
                  <div className="absolute top-0 right-0 p-1">
                    <div className="w-1 h-1 rounded-full bg-emerald-500/30"></div>
                  </div>
                  <div className="flex justify-between items-start mb-2">
                    <span className="text-[9px] font-bold text-zinc-600 mono">{new Date(log.created_at).toLocaleTimeString()}</span>
                    <span className="text-[9px] font-black text-emerald-500/80 uppercase">Incoming_Mail</span>
                  </div>
                  <p className="font-bold text-xs text-zinc-200 line-clamp-1 group-hover:text-emerald-400 transition-colors">{log.subject}</p>
                  <p className="text-[10px] text-zinc-500 line-clamp-2 mt-1 leading-normal font-medium">{log.snippet}</p>
                </div>
              ))
            ) : (
              <div className="h-full flex flex-col items-center justify-center opacity-10 text-center">
                <Shield size={64} strokeWidth={1} className="mb-4" />
                <p className="text-sm font-bold mono">Waiting for secure data...</p>
              </div>
            )}
          </div>
          
          <div className="mt-6 pt-6 border-t border-zinc-800/50 flex items-center justify-between">
             <div className="flex items-center gap-2">
                <div className="w-8 h-8 bg-zinc-900 rounded-lg flex items-center justify-center border border-zinc-800">
                  <Package size={16} className="text-zinc-500" />
                </div>
                <div>
                   <p className="text-[9px] text-zinc-600 font-bold uppercase">Total Items</p>
                   <p className="text-xs font-black mono text-zinc-300">{state.inventory.length}</p>
                </div>
             </div>
             <button className="text-[10px] font-black text-emerald-500 hover:text-emerald-400 transition-all uppercase tracking-widest">View All</button>
          </div>
        </div>
      </div>
    </div>
  );
};

const StatCard: React.FC<{ label: string, value: string, icon: React.ReactNode, trend: string, color: string }> = ({ label, value, icon, trend, color }) => {
  const colors: Record<string, string> = {
    emerald: 'border-emerald-500/20 hover:border-emerald-500/40 shadow-emerald-500/5',
    blue: 'border-blue-500/20 hover:border-blue-500/40 shadow-blue-500/5',
    indigo: 'border-indigo-500/20 hover:border-indigo-500/40 shadow-indigo-500/5',
    rose: 'border-rose-500/20 hover:border-rose-500/40 shadow-rose-500/5',
  };

  return (
    <div className={`glass p-6 rounded-[1.75rem] border transition-all hover:translate-y-[-4px] shadow-lg group ${colors[color]}`}>
      <div className="flex justify-between items-start mb-4">
        <div className="p-3 bg-zinc-900/80 rounded-2xl border border-zinc-800 group-hover:scale-110 transition-transform">{icon}</div>
        <div className="h-1.5 w-1.5 rounded-full bg-zinc-700 group-hover:bg-emerald-500 transition-colors"></div>
      </div>
      <p className="text-zinc-500 text-[10px] font-black uppercase tracking-[0.15em] mb-1">{label}</p>
      <h4 className="text-2xl font-black text-zinc-100 mono">{value}</h4>
      <div className="flex items-center gap-1 mt-3">
        <div className="h-[2px] w-4 bg-emerald-500/30"></div>
        <p className="text-zinc-600 text-[9px] font-bold uppercase tracking-wider">{trend}</p>
      </div>
    </div>
  );
};

export default Dashboard;
