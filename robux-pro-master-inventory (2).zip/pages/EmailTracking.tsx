
import React, { useState } from 'react';
import { EmailTracking, EmailStep, EmailLog } from '../types';
import { Plus, Trash2, Mail, CheckCircle2, Circle, Clock, RefreshCcw, Loader2, History, Shield, Database, Terminal } from 'lucide-react';
import { Link } from 'react-router-dom';

interface EmailTrackingProps {
  items: EmailTracking[];
  onAdd: (item: EmailTracking) => void;
  onUpdate: (item: EmailTracking) => void;
  onDelete: (id: string) => void;
  onAddLogs: (logs: EmailLog[]) => void;
}

const STEPS: { key: EmailStep; label: string; icon: any }[] = [
  { key: 'Ready', label: 'Ready', icon: Shield },
  { key: 'Login-Pending', label: 'Auth', icon: Terminal },
  { key: 'OTP-Waiting', label: 'OTP Wait', icon: Clock },
  { key: 'Purchasing', label: 'Process', icon: Database },
  { key: 'Success', label: 'Success', icon: CheckCircle2 },
];

const EmailTrackingPage: React.FC<EmailTrackingProps> = ({ items, onAdd, onUpdate, onDelete, onAddLogs }) => {
  const [showAddModal, setShowAddModal] = useState(false);
  const [isFetching, setIsFetching] = useState<string | null>(null);
  const [formData, setFormData] = useState({ email: '', usagePercent: 0, robuxStatus: '', cookies: '' });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onAdd({ ...formData, id: Math.random().toString(36).substr(2, 9), currentStep: 'Ready' });
    setShowAddModal(false);
    setFormData({ email: '', usagePercent: 0, robuxStatus: '', cookies: '' });
  };

  const handleFetchEmails = async (item: EmailTracking) => {
    if (!item.cookies) return;
    setIsFetching(item.id);

    try {
      // ตัวอย่างจำลองการ Fetch (ในระบบจริงจะยิงไป API /api/fetch-gmail)
      await new Promise(r => setTimeout(r, 2000));
      
      const newLogs: EmailLog[] = [
        {
          id: `real-${Date.now()}`,
          created_at: new Date().toISOString(),
          subject: 'Roblox Verification Code: 543210',
          snippet: 'Your verification code for Roblox is 543210. Please enter it to continue...',
          status: 'unread',
          account_id: item.email
        }
      ];
      
      onAddLogs(newLogs);
      onUpdate({ ...item, lastFetch: new Date().toISOString() });
    } catch (err) {
      console.error(err);
    } finally {
      setIsFetching(null);
    }
  };

  return (
    <div className="space-y-8 animate-in fade-in duration-700">
      <div className="flex justify-between items-end">
        <div>
          <div className="flex items-center gap-2 text-emerald-500 mb-2 font-black text-[10px] uppercase tracking-widest">
            <Shield size={14} /> Automation Gateway
          </div>
          <h1 className="text-4xl font-extrabold tracking-tighter">Session Tracker</h1>
          <p className="text-zinc-500 text-sm font-medium mt-1">Manage secure Gmail sessions and automated verification tokens.</p>
        </div>
        <button 
          onClick={() => setShowAddModal(true)} 
          className="bg-zinc-100 hover:bg-white text-zinc-950 font-black px-6 py-3 rounded-2xl flex items-center gap-2 transition-all shadow-[0_0_20px_rgba(255,255,255,0.1)] active:scale-95"
        >
          <Plus size={18} strokeWidth={3} /> REGISTER SESSION
        </button>
      </div>

      <div className="grid grid-cols-1 gap-6">
        {items.map((item) => (
          <div key={item.id} className="glass p-8 rounded-[2rem] glow-border transition-all flex flex-col lg:flex-row gap-10 items-center">
            {/* Account Profile */}
            <div className="w-full lg:w-[300px] space-y-5">
              <div className="flex items-center gap-4">
                <div className={`p-4 rounded-2xl border-2 ${item.cookies ? 'bg-emerald-500/5 border-emerald-500/30' : 'bg-zinc-900 border-zinc-800'}`}>
                  <Mail className={item.cookies ? "text-emerald-500" : "text-zinc-700"} size={28} />
                </div>
                <div className="min-w-0">
                  <h3 className="font-black text-xl text-zinc-100 truncate tracking-tight">{item.email}</h3>
                  <div className="flex items-center gap-2 mt-1">
                    <div className={`w-1.5 h-1.5 rounded-full ${item.cookies ? 'bg-emerald-500 shadow-[0_0_8px_#10b981]' : 'bg-rose-500'}`}></div>
                    <span className="text-[10px] font-black uppercase text-zinc-500 tracking-widest">{item.cookies ? 'Authorized' : 'Unauthorized'}</span>
                  </div>
                </div>
              </div>

              <div className="flex gap-2">
                <button 
                  disabled={!item.cookies || isFetching === item.id}
                  onClick={() => handleFetchEmails(item)}
                  className="flex-1 bg-zinc-900 hover:bg-zinc-800 disabled:opacity-20 text-emerald-500 py-3 rounded-xl text-[10px] font-black uppercase tracking-widest flex items-center justify-center gap-2 border border-zinc-800 hover:border-emerald-500/40 transition-all"
                >
                  {isFetching === item.id ? <Loader2 size={14} className="animate-spin" /> : <RefreshCcw size={14} />}
                  SYNC_CORE
                </button>
                <Link to={`/logs/${encodeURIComponent(item.email)}`} className="p-3 glass hover:bg-zinc-800 rounded-xl transition-all border-zinc-800 group">
                  <History size={18} className="text-zinc-500 group-hover:text-zinc-100" />
                </Link>
              </div>
              
              <div className="space-y-2">
                <div className="flex justify-between text-[9px] font-black text-zinc-600 uppercase tracking-[0.2em]">
                  <span>Resource Usage</span>
                  <span>{item.usagePercent}%</span>
                </div>
                <div className="h-1.5 w-full bg-zinc-900 rounded-full overflow-hidden p-[2px]">
                  <div className="h-full bg-emerald-500 rounded-full shadow-[0_0_10px_rgba(16,185,129,0.5)] transition-all" style={{ width: `${item.usagePercent}%` }}></div>
                </div>
              </div>
            </div>

            {/* Pipeline Steps */}
            <div className="flex-1 w-full bg-[#070708] border border-zinc-800/50 p-6 rounded-3xl relative overflow-hidden">
               <div className="absolute top-0 right-0 opacity-[0.03] p-4"><Terminal size={120} /></div>
               <div className="flex items-center justify-between gap-4 overflow-x-auto pb-4 custom-scrollbar">
                  {STEPS.map((step, idx) => {
                    const isCurrent = item.currentStep === step.key;
                    const isPast = STEPS.findIndex(s => s.key === item.currentStep) > idx;
                    const Icon = step.icon;
                    
                    return (
                      <React.Fragment key={step.key}>
                        <div className="flex flex-col items-center gap-3 shrink-0">
                          <div className={`w-14 h-14 rounded-2xl flex items-center justify-center border-2 transition-all duration-500 ${isCurrent ? 'bg-emerald-500 border-emerald-400 text-zinc-950 shadow-[0_0_30px_rgba(16,185,129,0.2)]' : isPast ? 'bg-emerald-500/5 border-emerald-500/20 text-emerald-500' : 'bg-zinc-900/50 border-zinc-800 text-zinc-700'}`}>
                            <Icon size={24} className={isCurrent ? "animate-pulse" : ""} />
                          </div>
                          <span className={`text-[10px] font-black uppercase tracking-widest ${isCurrent ? 'text-emerald-500' : 'text-zinc-700'}`}>{step.label}</span>
                        </div>
                        {idx < STEPS.length - 1 && <div className={`h-[2px] w-8 shrink-0 rounded-full ${isPast ? 'bg-emerald-500/40' : 'bg-zinc-900'} mt-7`} />}
                      </React.Fragment>
                    );
                  })}
               </div>
            </div>

            <button onClick={() => onDelete(item.id)} className="p-4 text-zinc-700 hover:text-rose-500 transition-all rounded-full hover:bg-rose-500/5"><Trash2 size={22} /></button>
          </div>
        ))}
      </div>

      {showAddModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/95 backdrop-blur-xl p-4">
          <div className="glass border-emerald-500/10 w-full max-w-2xl rounded-[2.5rem] p-10 shadow-2xl animate-in zoom-in-95 duration-300">
            <div className="flex justify-between items-start mb-10">
              <div>
                <h2 className="text-3xl font-black tracking-tighter">New Authentication</h2>
                <p className="text-zinc-500 text-sm font-medium mt-1">Initialize automated session scraper via secure cookies.</p>
              </div>
              <button onClick={() => setShowAddModal(false)} className="p-3 bg-zinc-900 rounded-full hover:bg-zinc-800 text-zinc-500 transition-all"><Plus className="rotate-45" /></button>
            </div>

            <form onSubmit={handleSubmit} className="space-y-8">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label className="text-[10px] font-black text-zinc-500 uppercase tracking-widest ml-1">Target Account</label>
                  <input 
                    required 
                    type="email" 
                    placeholder="example@gmail.com" 
                    className="w-full bg-zinc-900/50 border border-zinc-800 rounded-2xl px-5 py-4 outline-none focus:ring-2 focus:ring-emerald-500/50 text-zinc-100 mono text-sm transition-all" 
                    value={formData.email} 
                    onChange={e => setFormData({...formData, email: e.target.value})} 
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-[10px] font-black text-zinc-500 uppercase tracking-widest ml-1">Session Note</label>
                  <input 
                    placeholder="e.g. Primary Buyer" 
                    className="w-full bg-zinc-900/50 border border-zinc-800 rounded-2xl px-5 py-4 outline-none focus:ring-2 focus:ring-emerald-500/50 text-zinc-100 text-sm transition-all" 
                    value={formData.robuxStatus} 
                    onChange={e => setFormData({...formData, robuxStatus: e.target.value})} 
                  />
                </div>
              </div>

              <div className="space-y-3">
                <div className="flex justify-between items-center ml-1">
                  <label className="text-[10px] font-black text-emerald-500 uppercase tracking-widest">JSON_CORE_COOKIES</label>
                  <span className="text-[9px] text-zinc-600 font-bold uppercase tracking-tighter italic">Required for Playwright Script</span>
                </div>
                <textarea 
                  required
                  placeholder='[{"name":"SID","value":"..."}, ...]'
                  className="w-full h-48 bg-[#050506] border border-zinc-800 rounded-2xl px-5 py-4 outline-none focus:ring-2 focus:ring-emerald-500/50 mono text-[10px] text-emerald-500/60 leading-relaxed custom-scrollbar"
                  value={formData.cookies}
                  onChange={e => setFormData({...formData, cookies: e.target.value})}
                ></textarea>
                <div className="flex items-center gap-2 px-1 text-zinc-600">
                  <Terminal size={12} />
                  <p className="text-[9px] font-bold uppercase tracking-wider">Paste raw exported JSON cookies to bridge secure tunnel</p>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4 pt-4">
                <button type="button" onClick={() => setShowAddModal(false)} className="bg-zinc-900 hover:bg-zinc-800 text-zinc-500 font-black py-4 rounded-2xl transition-all uppercase tracking-widest">Discard</button>
                <button type="submit" className="bg-emerald-500 hover:bg-emerald-400 text-zinc-950 font-black py-4 rounded-2xl shadow-[0_0_25px_rgba(16,185,129,0.3)] transition-all uppercase tracking-widest">Initialize Link</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default EmailTrackingPage;
