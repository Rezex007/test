
import React, { useState } from 'react';
import { PaymentInfo } from '../types';
import { Plus, Trash2, Eye, EyeOff, ShieldCheck, CreditCard } from 'lucide-react';

interface PaymentProps {
  items: PaymentInfo[];
  onAdd: (item: PaymentInfo) => void;
  onDelete: (id: string) => void;
}

const Payment: React.FC<PaymentProps> = ({ items, onAdd, onDelete }) => {
  const [showAddModal, setShowAddModal] = useState(false);
  const [visibleInfo, setVisibleInfo] = useState<Record<string, boolean>>({});

  const [formData, setFormData] = useState({
    cardName: '',
    cardNumber: '',
    expiry: '',
    cvv: ''
  });

  const toggleVisibility = (id: string) => {
    setVisibleInfo(prev => ({ ...prev, [id]: !prev[id] }));
  };

  const maskCard = (num: string) => {
    return `**** **** **** ${num.slice(-4)}`;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onAdd({ ...formData, id: Math.random().toString(36).substr(2, 9) });
    setShowAddModal(false);
    setFormData({ cardName: '', cardNumber: '', expiry: '', cvv: '' });
  };

  return (
    <div className="space-y-6 animate-in slide-in-from-right-4 duration-500">
      <div className="flex justify-between items-end">
        <div>
          <h1 className="text-3xl font-bold">Payment Methods</h1>
          <p className="text-zinc-400">Securely manage cards used for Robux purchases.</p>
        </div>
        <button 
          onClick={() => setShowAddModal(true)}
          className="bg-zinc-100 hover:bg-white text-zinc-950 font-bold px-4 py-2 rounded-xl flex items-center gap-2 transition-colors"
        >
          <Plus size={20} />
          Add Card
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {items.map((card) => (
          <div key={card.id} className="bg-zinc-900 border border-zinc-800 rounded-2xl overflow-hidden shadow-lg hover:border-zinc-700 transition-all group">
            <div className="p-6 space-y-4">
              <div className="flex justify-between items-start">
                <div className="bg-zinc-800 p-2 rounded-lg">
                  <CreditCard className="text-emerald-500" />
                </div>
                <div className="flex items-center gap-2">
                  <button 
                    onClick={() => toggleVisibility(card.id)}
                    className="p-2 text-zinc-500 hover:text-zinc-300 transition-colors"
                  >
                    {visibleInfo[card.id] ? <EyeOff size={18} /> : <Eye size={18} />}
                  </button>
                  <button 
                    onClick={() => onDelete(card.id)}
                    className="p-2 text-zinc-500 hover:text-red-500 transition-colors opacity-0 group-hover:opacity-100"
                  >
                    <Trash2 size={18} />
                  </button>
                </div>
              </div>
              
              <div>
                <p className="text-zinc-500 text-xs uppercase font-bold tracking-wider">Card Name</p>
                <p className="text-lg font-semibold">{card.cardName}</p>
              </div>

              <div>
                <p className="text-zinc-500 text-xs uppercase font-bold tracking-wider">Number</p>
                <p className="text-xl font-mono tracking-widest mt-1">
                  {visibleInfo[card.id] ? card.cardNumber.replace(/(\d{4})/g, '$1 ').trim() : maskCard(card.cardNumber)}
                </p>
              </div>

              <div className="flex gap-12">
                <div>
                  <p className="text-zinc-500 text-xs uppercase font-bold tracking-wider">Expiry</p>
                  <p className="font-mono">{card.expiry}</p>
                </div>
                <div>
                  <p className="text-zinc-500 text-xs uppercase font-bold tracking-wider">CVV</p>
                  <p className="font-mono">{visibleInfo[card.id] ? card.cvv : '***'}</p>
                </div>
              </div>
            </div>
            <div className="bg-emerald-500/5 px-6 py-3 border-t border-zinc-800 flex items-center gap-2">
              <ShieldCheck size={14} className="text-emerald-500" />
              <span className="text-[10px] text-emerald-500/80 font-bold uppercase">Encrypted in Local Storage</span>
            </div>
          </div>
        ))}
      </div>

      {items.length === 0 && (
        <div className="text-center py-20 border-2 border-dashed border-zinc-800 rounded-3xl">
          <CreditCard className="mx-auto text-zinc-700 mb-4" size={48} />
          <p className="text-zinc-500">No payment methods stored.</p>
        </div>
      )}

      {/* Add Card Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4">
          <div className="bg-zinc-950 border border-zinc-800 w-full max-w-md rounded-3xl p-8 shadow-2xl animate-in zoom-in-95">
            <h2 className="text-2xl font-bold mb-6">Add New Card</h2>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-zinc-400 mb-1">Display Name</label>
                <input 
                  required
                  placeholder="e.g. My Primary Visa"
                  className="w-full bg-zinc-900 border border-zinc-800 rounded-xl px-4 py-3 outline-none focus:ring-2 focus:ring-emerald-500"
                  value={formData.cardName}
                  onChange={e => setFormData({...formData, cardName: e.target.value})}
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-zinc-400 mb-1">Card Number</label>
                <input 
                  required
                  maxLength={16}
                  placeholder="0000 0000 0000 0000"
                  className="w-full bg-zinc-900 border border-zinc-800 rounded-xl px-4 py-3 outline-none focus:ring-2 focus:ring-emerald-500 font-mono"
                  value={formData.cardNumber}
                  onChange={e => setFormData({...formData, cardNumber: e.target.value.replace(/\D/g, '')})}
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-zinc-400 mb-1">Expiry (MM/YY)</label>
                  <input 
                    required
                    placeholder="12/28"
                    className="w-full bg-zinc-900 border border-zinc-800 rounded-xl px-4 py-3 outline-none focus:ring-2 focus:ring-emerald-500 font-mono"
                    value={formData.expiry}
                    onChange={e => setFormData({...formData, expiry: e.target.value})}
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-zinc-400 mb-1">CVV</label>
                  <input 
                    required
                    maxLength={4}
                    placeholder="123"
                    className="w-full bg-zinc-900 border border-zinc-800 rounded-xl px-4 py-3 outline-none focus:ring-2 focus:ring-emerald-500 font-mono"
                    value={formData.cvv}
                    onChange={e => setFormData({...formData, cvv: e.target.value.replace(/\D/g, '')})}
                  />
                </div>
              </div>

              <div className="pt-6 flex gap-3">
                <button 
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="flex-1 bg-zinc-900 hover:bg-zinc-800 text-zinc-400 py-3 rounded-xl transition-colors"
                >
                  Cancel
                </button>
                <button 
                  type="submit"
                  className="flex-1 bg-white hover:bg-zinc-100 text-zinc-950 font-bold py-3 rounded-xl transition-colors"
                >
                  Save Method
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default Payment;
