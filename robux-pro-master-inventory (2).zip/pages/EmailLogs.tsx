
import React from 'react';
import { Link } from 'react-router-dom';
import { EmailLog, EmailTracking } from '../types';
import { Search, History, ChevronRight, Mail, MessageSquare, AlertCircle } from 'lucide-react';

interface EmailLogsProps {
  logs: EmailLog[];
  emails: EmailTracking[];
}

const EmailLogsPage: React.FC<EmailLogsProps> = ({ logs, emails }) => {
  const [searchTerm, setSearchTerm] = React.useState('');

  // รวมกลุ่ม Logs และ Emails เข้าด้วยกัน
  const accounts = React.useMemo(() => {
    const accMap: Record<string, { email: string, count: number, lastLog: string | null, hasCookies: boolean }> = {};
    
    // 1. เริ่มจากรายชื่ออีเมลที่ลงทะเบียนไว้ทั้งหมด
    emails.forEach(item => {
      accMap[item.email] = { 
        email: item.email, 
        count: 0, 
        lastLog: null,
        hasCookies: !!item.cookies 
      };
    });

    // 2. นำข้อมูลจาก Logs มาสรุปยอดและหาวันที่ล่าสุด
    logs.forEach(log => {
      if (!accMap[log.account_id]) {
        // กรณีมี log แต่ไม่มีในรายชื่อ tracker (เช่น ลบเมลออกแต่ log ยังอยู่)
        accMap[log.account_id] = { email: log.account_id, count: 0, lastLog: log.created_at, hasCookies: false };
      }
      accMap[log.account_id].count += 1;
      if (!accMap[log.account_id].lastLog || new Date(log.created_at) > new Date(accMap[log.account_id].lastLog!)) {
        accMap[log.account_id].lastLog = log.created_at;
      }
    });
    
    return Object.values(accMap)
      .filter(acc => acc.email.toLowerCase().includes(searchTerm.toLowerCase()))
      .sort((a, b) => {
        // เรียงลำดับ: ใครมี log ล่าสุดอยู่บนสุด ถ้าไม่มี log เลยอยู่ล่าง
        if (!a.lastLog && !b.lastLog) return 0;
        if (!a.lastLog) return 1;
        if (!b.lastLog) return -1;
        return new Date(b.lastLog).getTime() - new Date(a.lastLog).getTime();
      });
  }, [logs, emails, searchTerm]);

  return (
    <div className="space-y-6 animate-in slide-in-from-bottom-4 duration-500">
      <header>
        <h1 className="text-3xl font-bold">Automation Logs</h1>
        <p className="text-zinc-400">View message history for all registered email sessions.</p>
      </header>

      <div className="bg-zinc-900/50 border border-zinc-800 rounded-3xl overflow-hidden mb-6">
        <div className="p-4 border-b border-zinc-800 bg-zinc-950/50 flex flex-col md:flex-row justify-between gap-4">
           <div className="relative flex-1 max-w-md">
             <Search size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-zinc-600" />
             <input 
                type="text" 
                placeholder="Filter by email address..." 
                className="w-full bg-zinc-900 border border-zinc-800 rounded-xl py-2 pl-10 pr-4 outline-none focus:ring-2 focus:ring-emerald-500 text-sm"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
             />
           </div>
           <div className="flex items-center gap-2 text-[10px] font-bold text-emerald-500 bg-emerald-500/10 px-4 py-2 rounded-full border border-emerald-500/20">
             <div className="w-1.5 h-1.5 bg-emerald-500 rounded-full animate-pulse"></div>
             {emails.length} REGISTERED ACCOUNTS
           </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {accounts.map((acc) => (
          <Link 
            key={acc.email} 
            to={`/logs/${encodeURIComponent(acc.email)}`}
            className="group bg-zinc-900/50 border border-zinc-800 p-6 rounded-3xl hover:border-emerald-500/40 hover:bg-zinc-900 transition-all shadow-xl block relative overflow-hidden"
          >
            <div className="flex justify-between items-start mb-4">
              <div className={`p-3 bg-zinc-950 rounded-2xl border ${acc.hasCookies ? 'border-emerald-500/30' : 'border-zinc-800'} group-hover:border-emerald-500/30 transition-all`}>
                <Mail className={`${acc.hasCookies ? 'text-emerald-500' : 'text-zinc-600'} group-hover:text-emerald-500 transition-all`} />
              </div>
              <div className={`flex items-center gap-1 text-[10px] font-bold px-2 py-1 rounded-full border ${acc.count > 0 ? 'text-emerald-500 bg-emerald-500/10 border-emerald-500/20' : 'text-zinc-500 bg-zinc-800 border-zinc-700'}`}>
                {acc.count > 0 ? (
                  <>
                    <div className="w-1.5 h-1.5 bg-emerald-500 rounded-full animate-pulse"></div>
                    ACTIVE
                  </>
                ) : (
                  'PENDING FETCH'
                )}
              </div>
            </div>
            
            <div className="space-y-1 mb-6">
              <h3 className="font-bold text-lg truncate group-hover:text-emerald-400 transition-all">{acc.email}</h3>
              <p className="text-zinc-500 text-xs flex items-center gap-2">
                <History size={12} />
                {acc.lastLog ? `Last message: ${new Date(acc.lastLog).toLocaleString()}` : 'No messages received yet'}
              </p>
            </div>

            <div className="flex items-center justify-between pt-4 border-t border-zinc-800/50">
              <div className="flex items-center gap-2 text-zinc-400">
                <MessageSquare size={16} />
                <span className="text-sm font-bold">{acc.count} Messages</span>
              </div>
              <ChevronRight size={18} className="text-zinc-600 group-hover:translate-x-1 transition-transform" />
            </div>

            {!acc.hasCookies && acc.count === 0 && (
              <div className="absolute top-2 right-2" title="No cookies provided">
                <AlertCircle size={14} className="text-amber-500/50" />
              </div>
            )}
          </Link>
        ))}

        {accounts.length === 0 && (
          <div className="col-span-full p-20 text-center flex flex-col items-center gap-4 bg-zinc-900/20 border-2 border-dashed border-zinc-800 rounded-3xl">
            <History size={64} className="text-zinc-900" />
            <p className="text-zinc-600 font-medium">No accounts found. Add your first email in the Email Tracker page.</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default EmailLogsPage;
