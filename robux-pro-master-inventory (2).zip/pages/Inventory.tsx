
import React, { useState } from 'react';
import { InventoryItem, Status, AppState } from '../types';
import { Plus, Search, Trash2, Eye, EyeOff, Mail, CreditCard, AlertCircle, RefreshCcw } from 'lucide-react';
import { Link } from 'react-router-dom';

interface InventoryProps {
  items: InventoryItem[];
  emails: AppState['emails'];
  payments: AppState['payments'];
  onAdd: (item: InventoryItem) => void;
  onDelete: (id: string) => void;
}

const Inventory: React.FC<InventoryProps> = ({ items, emails, payments, onAdd, onDelete }) => {
  const [showAddModal, setShowAddModal] = useState(false);
  const [showPasswords, setShowPasswords] = useState<Record<string, boolean>>({});
  const [search, setSearch] = useState('');

  const [formData, setFormData] = useState({
    robloxId: '',
    robloxPass: '',
    status: 'Unsold' as Status,
    cost: 0,
    price: 0,
    robuxAmount: 0,
    emailUsed: '',
    cardUsed: ''
  });

  const togglePass = (id: string) => {
    setShowPasswords(prev => ({ ...prev, [id]: !prev[id] }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const newItem: InventoryItem = {
      ...formData,
      id: Math.random().toString(36).substr(2, 9),
      updatedAt: new Date().toISOString()
    };
    onAdd(newItem);
    setShowAddModal(false);
    setFormData({ robloxId: '', robloxPass: '', status: 'Unsold', cost: 0, price: 0, robuxAmount: 0, emailUsed: '', cardUsed: '' });
  };

  const filteredItems = items.filter(item => 
    item.robloxId.toLowerCase().includes(search.toLowerCase()) ||
    (item.emailUsed && item.emailUsed.toLowerCase().includes(search.toLowerCase()))
  );

  return (
    <div className="space-y-6 animate-in slide-in-from-bottom-4 duration-500">
      <div className="flex justify-between items-end">
        <div>
          <h1 className="text-3xl font-bold">Stock & Tracking</h1>
          <p className="text-zinc-400">Inventory audit: See exactly which card and email were used.</p>
        </div>
        <button 
          onClick={() => setShowAddModal(true)}
          className="bg-emerald-500 hover:bg-emerald-600 text-zinc-950 font-bold px-4 py-2 rounded-xl flex items-center gap-2 transition-colors shadow-lg shadow-emerald-500/10"
        >
          <Plus size={20} /> Add Account
        </button>
      </div>

      <div className="relative w-full">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-zinc-500" size={18} />
        <input 
          type="text"
          placeholder="Search by Roblox ID or Linked Email..."
          className="w-full bg-zinc-900/50 border border-zinc-800 rounded-xl py-3 pl-10 pr-4 focus:ring-2 focus:ring-emerald-500 outline-none transition-all"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
        />
      </div>

      <div className="bg-zinc-900/30 border border-zinc-800 rounded-3xl overflow-hidden shadow-2xl">
        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead className="bg-zinc-950/50 border-b border-zinc-800">
              <tr>
                <th className="p-4 font-semibold text-zinc-400 text-xs uppercase tracking-wider">Roblox Info</th>
                <th className="p-4 font-semibold text-zinc-400 text-xs uppercase tracking-wider">Purchase Source</th>
                <th className="p-4 font-semibold text-zinc-400 text-xs uppercase tracking-wider text-center">Sales Status</th>
                <th className="p-4 font-semibold text-zinc-400 text-xs uppercase tracking-wider text-right">Profit</th>
                <th className="p-4 font-semibold text-zinc-400 text-xs uppercase tracking-wider text-center">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-zinc-800">
              {filteredItems.map((item) => {
                const profit = item.price - item.cost;
                return (
                  <tr key={item.id} className="hover:bg-zinc-800/40 transition-colors group">
                    <td className="p-4">
                      <div className="font-bold text-zinc-100 flex items-center gap-2">
                        {item.robloxId}
                        <span className="text-[10px] bg-zinc-800 px-1.5 py-0.5 rounded text-zinc-500 font-mono">ID:{item.id}</span>
                      </div>
                      <div className="flex items-center gap-2 mt-1">
                        <span className="text-[10px] font-mono text-zinc-500 bg-zinc-950 px-1.5 py-0.5 rounded border border-zinc-800">
                          {showPasswords[item.id] ? item.robloxPass : '••••••••'}
                        </span>
                        <button onClick={() => togglePass(item.id)} className="text-zinc-600 hover:text-zinc-300">
                          {showPasswords[item.id] ? <EyeOff size={12} /> : <Eye size={12} />}
                        </button>
                      </div>
                    </td>
                    <td className="p-4">
                      <div className="space-y-1.5">
                        {item.emailUsed ? (
                          <Link to={`/logs/${encodeURIComponent(item.emailUsed)}`} className="flex items-center gap-2 text-xs text-zinc-400 hover:text-emerald-400 transition-colors">
                            <Mail size={14} className="text-emerald-500/60" /> {item.emailUsed}
                          </Link>
                        ) : <div className="text-xs text-zinc-700 italic">No email linked</div>}
                        {item.cardUsed ? (
                          <div className="flex items-center gap-2 text-xs text-zinc-400">
                            <CreditCard size={14} className="text-blue-500/60" /> {item.cardUsed}
                          </div>
                        ) : <div className="text-xs text-zinc-700 italic">No card linked</div>}
                      </div>
                    </td>
                    <td className="p-4 text-center">
                       <div className="flex flex-col items-center gap-1">
                          <span className={`px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-wider border ${
                            item.status === 'Sold' ? 'bg-emerald-500/10 text-emerald-500 border-emerald-500/20' : 
                            item.status === 'Refunded' ? 'bg-red-500/10 text-red-500 border-red-500/20' :
                            item.status === 'Pending-Refund' ? 'bg-amber-500/10 text-amber-500 border-amber-500/20' :
                            'bg-zinc-800 text-zinc-400 border-zinc-700'
                          }`}>
                            {item.status}
                          </span>
                          {item.refundReason && <span className="text-[9px] text-red-500/70 font-medium italic">{item.refundReason}</span>}
                       </div>
                    </td>
                    <td className="p-4 text-right">
                      <div className="text-xs text-zinc-500 font-medium">฿{item.price.toLocaleString()}</div>
                      <div className={`text-sm font-black ${profit >= 0 ? 'text-emerald-400' : 'text-red-400'}`}>
                        {profit >= 0 ? '+' : ''}{profit.toLocaleString()}
                      </div>
                    </td>
                    <td className="p-4 text-center">
                      <div className="flex items-center justify-center gap-2">
                        <button onClick={() => onDelete(item.id)} className="p-2 text-zinc-600 hover:text-red-500 transition-colors hover:bg-red-500/10 rounded-lg"><Trash2 size={16} /></button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {showAddModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/90 backdrop-blur-sm p-4">
          <div className="bg-zinc-950 border border-zinc-800 w-full max-w-lg rounded-3xl p-8 shadow-2xl animate-in zoom-in-95">
            <h2 className="text-2xl font-bold mb-6">Register Account to Stock</h2>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-zinc-500 uppercase mb-1 ml-1">Roblox Username</label>
                  <input required className="w-full bg-zinc-900 border border-zinc-800 rounded-xl px-4 py-2 outline-none focus:ring-2 focus:ring-emerald-500" value={formData.robloxId} onChange={e => setFormData({...formData, robloxId: e.target.value})} />
                </div>
                <div>
                  <label className="block text-xs font-bold text-zinc-500 uppercase mb-1 ml-1">Password</label>
                  <input required type="password" className="w-full bg-zinc-900 border border-zinc-800 rounded-xl px-4 py-2 outline-none focus:ring-2 focus:ring-emerald-500" value={formData.robloxPass} onChange={e => setFormData({...formData, robloxPass: e.target.value})} />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-zinc-500 uppercase mb-1 ml-1">Email Used</label>
                  <select 
                    className="w-full bg-zinc-900 border border-zinc-800 rounded-xl px-4 py-2 outline-none focus:ring-2 focus:ring-emerald-500 text-sm"
                    value={formData.emailUsed}
                    onChange={e => setFormData({...formData, emailUsed: e.target.value})}
                  >
                    <option value="">-- No Email Linked --</option>
                    {emails.map(e => <option key={e.id} value={e.email}>{e.email}</option>)}
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-bold text-zinc-500 uppercase mb-1 ml-1">Card Used</label>
                  <select 
                    className="w-full bg-zinc-900 border border-zinc-800 rounded-xl px-4 py-2 outline-none focus:ring-2 focus:ring-emerald-500 text-sm"
                    value={formData.cardUsed}
                    onChange={e => setFormData({...formData, cardUsed: e.target.value})}
                  >
                    <option value="">-- No Card Linked --</option>
                    {payments.map(p => <option key={p.id} value={p.cardName}>{p.cardName}</option>)}
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-3 gap-4">
                <div>
                  <label className="block text-xs font-bold text-zinc-500 uppercase mb-1 ml-1">Robux Amount</label>
                  <input type="number" className="w-full bg-zinc-900 border border-zinc-800 rounded-xl px-4 py-2 outline-none focus:ring-2 focus:ring-emerald-500" value={formData.robuxAmount} onChange={e => setFormData({...formData, robuxAmount: Number(e.target.value)})} />
                </div>
                <div>
                  <label className="block text-xs font-bold text-zinc-500 uppercase mb-1 ml-1">Cost (฿)</label>
                  <input type="number" className="w-full bg-zinc-900 border border-zinc-800 rounded-xl px-4 py-2 outline-none focus:ring-2 focus:ring-emerald-500" value={formData.cost} onChange={e => setFormData({...formData, cost: Number(e.target.value)})} />
                </div>
                <div>
                  <label className="block text-xs font-bold text-zinc-500 uppercase mb-1 ml-1">Price (฿)</label>
                  <input type="number" className="w-full bg-zinc-900 border border-zinc-800 rounded-xl px-4 py-2 outline-none focus:ring-2 focus:ring-emerald-500" value={formData.price} onChange={e => setFormData({...formData, price: Number(e.target.value)})} />
                </div>
              </div>

              <div className="pt-4 flex gap-3">
                <button type="button" onClick={() => setShowAddModal(false)} className="flex-1 bg-zinc-900 text-zinc-500 py-3 rounded-xl font-bold">Cancel</button>
                <button type="submit" className="flex-1 bg-emerald-500 text-zinc-950 py-3 rounded-xl font-bold">Add to Stock</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default Inventory;
