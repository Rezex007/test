
import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { EmailLog } from '../types';
import { 
  ArrowLeft,
  Mail,
  X,
  User,
  Clock,
  ChevronRight,
  Star,
  Square,
  Tag,
  Users,
  Inbox,
  MoreVertical,
  RotateCcw
} from 'lucide-react';

interface AccountLogsProps {
  logs: EmailLog[];
}

const AccountLogsPage: React.FC<AccountLogsProps> = ({ logs }) => {
  const { emailId } = useParams<{ emailId: string }>();
  const decodedEmail = decodeURIComponent(emailId || '').toLowerCase(); // ทำเป็นตัวเล็กเพื่อให้ Match ง่ายขึ้น
  const [selectedLog, setSelectedLog] = useState<EmailLog | null>(null);
  const [activeTab, setActiveTab] = useState<'Primary' | 'Promotions' | 'Social'>('Primary');

  // กรอง Log ที่ตรงกับบัญชีที่เลือก
  const accountLogs = React.useMemo(() => {
    return logs.filter(log => log.account_id.toLowerCase() === decodedEmail)
               .sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime());
  }, [logs, decodedEmail]);

  return (
    <div className="h-full flex flex-col space-y-4 animate-in fade-in duration-500">
      <header className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <Link to="/logs" className="p-2 hover:bg-zinc-800 rounded-full transition-all text-zinc-400">
            <ArrowLeft size={20} />
          </Link>
          <h1 className="text-xl font-semibold">{decodedEmail}</h1>
        </div>
        <div className="flex items-center gap-2">
           <button className="p-2 hover:bg-zinc-800 rounded-full text-zinc-400"><RotateCcw size={18} /></button>
           <button className="p-2 hover:bg-zinc-800 rounded-full text-zinc-400"><MoreVertical size={18} /></button>
        </div>
      </header>

      <div className="bg-[#121212] border border-zinc-800 rounded-2xl overflow-hidden flex flex-col shadow-2xl h-[calc(100vh-180px)]">
        {/* Gmail Style Tabs */}
        <div className="flex border-b border-zinc-800">
          <TabButton 
            active={activeTab === 'Primary'} 
            onClick={() => setActiveTab('Primary')} 
            icon={<Inbox size={18} />} 
            label="Primary" 
            color="text-blue-500"
          />
          <TabButton 
            active={activeTab === 'Promotions'} 
            onClick={() => setActiveTab('Promotions')} 
            icon={<Tag size={18} />} 
            label="Promotions" 
            color="text-emerald-500"
          />
          <TabButton 
            active={activeTab === 'Social'} 
            onClick={() => setActiveTab('Social')} 
            icon={<Users size={18} />} 
            label="Social" 
            color="text-purple-500"
          />
        </div>

        {/* Inbox List */}
        <div className="flex-1 overflow-y-auto bg-[#0b0b0b]">
          {accountLogs.length > 0 ? (
            <div className="divide-y divide-zinc-800/50">
              {accountLogs.map((log) => {
                const isRoblox = log.subject.toLowerCase().includes('roblox');
                const isUnread = log.status === 'unread';
                const senderName = isRoblox ? 'Roblox' : 'Google';
                
                return (
                  <div 
                    key={log.id} 
                    onClick={() => setSelectedLog(log)}
                    className={`group flex items-center gap-4 px-4 py-2.5 cursor-pointer transition-all border-l-4 relative ${
                      isUnread ? 'bg-zinc-900/40 border-l-blue-500' : 'bg-transparent border-l-transparent hover:bg-zinc-800/50'
                    }`}
                  >
                    <div className="flex items-center gap-3 shrink-0 text-zinc-600">
                      <Square size={16} />
                      <Star size={16} />
                    </div>
                    
                    {/* Sender Name */}
                    <div className={`w-40 shrink-0 truncate ${isUnread ? 'font-bold text-zinc-100' : 'text-zinc-400 font-medium'}`}>
                      {senderName}
                    </div>
                    
                    {/* Subject & Snippet */}
                    <div className="flex-1 min-w-0 flex items-baseline gap-2">
                      <span className={`truncate ${isUnread ? 'font-bold text-zinc-100' : 'text-zinc-300 font-medium'}`}>
                        {log.subject}
                      </span>
                      <span className="text-zinc-500 text-sm truncate">— {log.snippet}</span>
                    </div>

                    {/* Time */}
                    <div className={`text-xs whitespace-nowrap pl-4 ${isUnread ? 'font-bold text-zinc-100' : 'text-zinc-500'}`}>
                      {new Date(log.created_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </div>
                  </div>
                );
              })}
            </div>
          ) : (
            <div className="h-full flex flex-col items-center justify-center p-20 gap-4 opacity-30 text-center">
              <Mail size={64} />
              <div>
                <p className="text-lg font-bold">No messages found for this account</p>
                <p className="text-sm">Make sure you have added logs for {decodedEmail}</p>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Message Viewer Modal */}
      {selectedLog && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/90 p-4 md:p-8 animate-in fade-in duration-200">
          <div className="bg-[#0f0f0f] border border-zinc-800 w-full max-w-5xl h-[85vh] rounded-3xl flex flex-col shadow-2xl overflow-hidden">
            <div className="p-4 border-b border-zinc-800 flex items-center justify-between bg-zinc-900/50">
              <div className="flex items-center gap-4">
                <button onClick={() => setSelectedLog(null)} className="p-2 hover:bg-zinc-800 rounded-full transition-all text-zinc-400">
                   <ArrowLeft size={20} />
                </button>
                <h2 className="text-lg font-semibold truncate">{selectedLog.subject}</h2>
              </div>
              <div className="flex gap-2">
                <button onClick={() => setSelectedLog(null)} className="p-2 hover:bg-zinc-800 rounded-full"><X size={20} /></button>
              </div>
            </div>

            <div className="flex-1 overflow-y-auto p-8 bg-[#0b0b0b]">
              <div className="max-w-3xl mx-auto">
                <div className="flex justify-between items-start mb-10">
                  <div className="flex gap-4">
                    <div className="w-12 h-12 bg-zinc-800 rounded-full flex items-center justify-center font-bold text-xl text-zinc-400">
                      {selectedLog.subject.toLowerCase().includes('roblox') ? 'R' : 'G'}
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-lg text-zinc-100">{selectedLog.subject.toLowerCase().includes('roblox') ? 'Roblox' : 'Google'}</span>
                        <span className="text-zinc-500 text-sm">&lt;noreply@{selectedLog.subject.toLowerCase().includes('roblox') ? 'roblox.com' : 'google.com'}&gt;</span>
                      </div>
                      <div className="text-zinc-500 text-xs mt-1">to me</div>
                    </div>
                  </div>
                  <div className="text-zinc-500 text-sm font-medium">
                    {new Date(selectedLog.created_at).toLocaleString()}
                  </div>
                </div>

                <div className="text-zinc-200 leading-relaxed text-lg whitespace-pre-wrap font-sans">
                  {selectedLog.snippet}
                  <br /><br />
                  <div className="p-8 bg-zinc-900/30 rounded-3xl border border-zinc-800/50 mt-8 italic text-zinc-500 text-sm leading-relaxed">
                    <p className="font-bold text-zinc-400 mb-2 underline">Scraper Meta Information</p>
                    Account: {selectedLog.account_id}<br/>
                    Status: {selectedLog.status.toUpperCase()}<br/>
                    Found At: {new Date(selectedLog.created_at).toLocaleString()}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

const TabButton: React.FC<{ active: boolean, onClick: () => void, icon: React.ReactNode, label: string, color: string }> = ({ active, onClick, icon, label, color }) => (
  <button 
    onClick={onClick}
    className={`flex items-center gap-4 px-8 py-4 text-sm font-medium transition-all relative ${active ? color : 'text-zinc-500 hover:bg-zinc-800/50'}`}
  >
    {icon}
    <span className={active ? "font-bold" : "font-medium"}>{label}</span>
    {active && <div className={`absolute bottom-0 left-0 right-0 h-1 ${color.replace('text-', 'bg-')}`}></div>}
  </button>
);

export default AccountLogsPage;
